/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.callamethod;

/**
 *
 * @author Lenovo-User
 */
public class Main {
   static void myMethod() {
       System.out.println("I just got excecuted");
   }
   public static void main(String[] args){
       myMethod();
   }
}
